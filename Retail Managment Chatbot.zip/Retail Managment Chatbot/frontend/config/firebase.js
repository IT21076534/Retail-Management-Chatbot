// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyDdIc9GBSZsezTc_Duo2XroDKSENzcJHzY",
  authDomain: "chatbot-bd512.firebaseapp.com",
  projectId: "chatbot-bd512",
  storageBucket: "chatbot-bd512.appspot.com",
  messagingSenderId: "211460332216",
  appId: "1:211460332216:web:384c184bd85ad4de2db24d",
  measurementId: "G-SD4041R9Z1"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);
