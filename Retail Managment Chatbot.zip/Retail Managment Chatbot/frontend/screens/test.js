function setprice (phoneName){
    console.log(phoneName);
    if(phoneName==="another13"){
          const message2 = {
                _id: Math.random().toString(36).substring(7),
                text: "phone price not found",
                user: {
                          _id: 2,
                          name: 'Chatbot',
                          avatar: 'https://placeimg.com/140/140/any',
                      },
                createdAt: new Date(), 
          };

          setMessages(previousMessages =>
            GiftedChat.append(previousMessages, message2)
          );

    } else{
          const collectionRef = collection(database, 'phone_prices');
          const q = query(collectionRef,where('phone_type', '==', {phoneName}));

          const unsubscribe = onSnapshot(q, querySnapshot => {
              console.log('querySnapshot unsusbscribe');

              querySnapshot.docs.map(doc => 
                price=doc.data().price,
                ); 

                const message2 = {
                    _id: Math.random().toString(36).substring(7),
                    text: price,
                    user: {
                            _id: 2,
                            name: 'Chatbot',
                            avatar: 'https://placeimg.com/140/140/any',
                        },
                    createdAt: new Date(), 
                };

                setMessages(previousMessages =>
                    GiftedChat.append(previousMessages, message2)
                );
            }


    }

  
};