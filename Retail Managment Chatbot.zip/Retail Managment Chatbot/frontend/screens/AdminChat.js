import React, {
  useState,
  useEffect,
  useLayoutEffect,
  useCallback,
} from "react";
import { TouchableOpacity, Text } from "react-native";
import { GiftedChat, QuickReplies } from "react-native-gifted-chat";
import {
  collection,
  addDoc,
  orderBy,
  where,
  query,
  onSnapshot,
} from "firebase/firestore";
import { signOut } from "firebase/auth";
import { auth, database } from "../config/firebase";
import { useNavigation } from "@react-navigation/native";
import { AntDesign } from "@expo/vector-icons";
import colors from "../colors";

export default function AdminChat() {
  const [messages, setMessages] = useState([]);
  const [count, setCount] = useState(0);
  const navigation = useNavigation();

  async function onQuickReply(quickReply = []) {
    console.log(quickReply[0].value);
    let message = quickReply[0].value;
    let msg = {
      _id: Math.random().toString(36).substring(7),
      text: message,
      createdAt: new Date(),
      user: {
        _id: 2,
        name: "Me",
        avatar: "https://placeimg.com/140/140/any",
      },
    };

    setMessages((previousMessages) => GiftedChat.append(previousMessages, msg));
  }

  const onSignOut = () => {
    signOut(auth).catch((error) => console.log("Error logging out: ", error));
  };

  useLayoutEffect(() => {
    navigation.setOptions({
      headerRight: () => (
        <TouchableOpacity
          style={{
            marginRight: 10,
          }}
          onPress={onSignOut}
        >
          <AntDesign
            name="logout"
            size={24}
            color={colors.gray}
            style={{ marginRight: 10 }}
          />
        </TouchableOpacity>
      ),
    });
  }, [navigation]);

  useEffect(() => {
    console.log("components mounted");
  }, []);

  function setValue(value) {
    console.log(value);

    const collectionRef = collection(database, "phone_sales");
    const q = query(collectionRef, where("sale_type", "==", value));
    var price = "";
    var message = "";

    const unsubscribe = onSnapshot(q, (querySnapshot) => {
      console.log("querySnapshot unsusbscribe");

      querySnapshot.docs.map((doc) => (price = doc.data().sales_amount));

      if (value == "sales_month") {
        message = `This month totol sales amount is ${price}.`;
      } else if (value == "sales_year") {
        message = `This year totol sales amount is ${price}.`;
      } else if (value == "sales_total") {
        message = `totol sales amount(untill now) is ${price}.`;
      }

      const message2 = {
        _id: Math.random().toString(36).substring(7),
        text: message,
        user: {
          _id: 2,
          name: "Chatbot",
          avatar: "https://placeimg.com/140/140/any",
        },
        createdAt: new Date(),
      };

      setMessages((previousMessages) =>
        GiftedChat.append(previousMessages, message2)
      );
    });
  }

  function setStockValue(value) {
    console.log(value);

    const collectionRef = collection(database, "phone_stock");
    const q = query(collectionRef, where("stock_type", "==", value));
    var stock = "";
    var message = "";

    const unsubscribe = onSnapshot(q, (querySnapshot) => {
      console.log("querySnapshot unsusbscribe");

      querySnapshot.docs.map((doc) => (stock = doc.data().stock_amount));

      console.log(stock);

      if (value == "stock_month") {
        message = `This month totol stock(all iphones type) amount is ${stock}.`;
      } else if (value == "stock_year") {
        message = `This year totol stock(all iphones type) amount is ${stock}.`;
      }

      const message2 = {
        _id: Math.random().toString(36).substring(7),
        text: message,
        user: {
          _id: 2,
          name: "Chatbot",
          avatar: "https://placeimg.com/140/140/any",
        },
        createdAt: new Date(),
      };

      setMessages((previousMessages) =>
        GiftedChat.append(previousMessages, message2)
      );
    });
  }

  function setForecastValue() {}

  async function handleSend(newMessages = []) {
    const newMessage = newMessages[0];
    console.log("nemw message arrived");
    console.log(newMessage);

    setMessages((previousMessages) =>
      GiftedChat.append(previousMessages, newMessage)
    );

    const { _id, createdAt, text, user } = newMessage;

    if (newMessage.user._id === 1) {
      const URL = "http://0.0.0.0:3000";
      const data = {
        // Replace with the data you want to send to the backend
        _id: _id,
        text: text,
      };
      fetch(`${URL}/admin`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      })
        .then((response) => response.json())
        .then((data) => {
          if (data["result"] == "sales_month") {
            console.log("sales_month");
            setValue("sales_month");
          } else if (data["result"] == "sales_year") {
            console.log("sales_year");
            setValue("sales_year");
          } else if (data["result"] == "sales_total") {
            console.log("sales_total");
            setValue("sales_total");
          } else if (data["result"] == "stock_month") {
            console.log("stock_month");
            setStockValue("stock_month");
          } else if (data["result"] == "stock_year") {
            console.log("stock_year");
            setStockValue("stock_year");
          } else {
            console.log("another");
            const message2 = {
              _id: Math.random().toString(36).substring(7),
              text: data["result"],
              user: {
                _id: 2,
                name: "Chatbot",
                avatar: "https://placeimg.com/140/140/any",
              },
              createdAt: new Date(),
            };

            setMessages((previousMessages) =>
              GiftedChat.append(previousMessages, message2)
            );
          }
          console.log("end of data feching");
        })
        .catch((error) => {
          // Handle any errors that occurred during the request
          console.error(error);
        });
    }
  }

  return (
    <GiftedChat
      messages={messages}
      onSend={handleSend}
      onQuickReply={onQuickReply}
      messagesContainerStyle={{
        backgroundColor: "#fff",
      }}
      textInputStyle={{
        backgroundColor: "#fff",
        borderRadius: 20,
      }}
      user={{
        _id: 1,
        name: "Me",
        avatar: "https://placeimg.com/140/140/any",
      }}
    />
  );
}
