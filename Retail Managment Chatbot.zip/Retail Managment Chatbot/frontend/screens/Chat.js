import React, {
  useState,
  useEffect,
  useLayoutEffect,
  useCallback,
} from "react";
import { TouchableOpacity, Text } from "react-native";
import { GiftedChat, QuickReplies } from "react-native-gifted-chat";
import {
  collection,
  addDoc,
  orderBy,
  where,
  query,
  onSnapshot,
} from "firebase/firestore";
import { signOut } from "firebase/auth";
import { auth, database } from "../config/firebase";
import { useNavigation } from "@react-navigation/native";
import { AntDesign } from "@expo/vector-icons";
import colors from "../colors";
import { encode, decode } from "base-64";

export default function Chat() {
  const [messages, setMessages] = useState([]);
  const [count, setCount] = useState(0);
  const navigation = useNavigation();

  async function onQuickReply(quickReply = []) {
    console.log(quickReply[0].value);
    let message = quickReply[0].value;
    let msg = {
      _id: Math.random().toString(36).substring(7),
      text: message,
      createdAt: new Date(),
      user: {
        _id: 2,
        name: "Me",
        avatar: "https://placeimg.com/140/140/any",
      },
    };

    setMessages((previousMessages) => GiftedChat.append(previousMessages, msg));
    // console.log(messages);

    // const { _id, createdAt, text, user } = msg;
    // addDoc(collection(database, 'chats'), {
    // _id,
    // createdAt,
    // text,
    // user
    // });
  }

  const onSignOut = () => {
    signOut(auth).catch((error) => console.log("Error logging out: ", error));
  };

  useLayoutEffect(() => {
    navigation.setOptions({
      headerRight: () => (
        <TouchableOpacity
          style={{
            marginRight: 10,
          }}
          onPress={onSignOut}
        >
          <AntDesign
            name="logout"
            size={24}
            color={colors.gray}
            style={{ marginRight: 10 }}
          />
        </TouchableOpacity>
      ),
    });
  }, [navigation]);

  useEffect(() => {
    // const collectionRef = collection(database, 'chats');
    // const q = query(collectionRef, orderBy('createdAt', 'desc'));

    // const unsubscribe = onSnapshot(q, querySnapshot => {
    //     console.log('querySnapshot unsusbscribe');
    //       // setMessages(
    //       //   querySnapshot.docs.map(doc => ({
    //       //     _id: doc.data()._id,
    //       //     createdAt: doc.data().createdAt.toDate(),
    //       //     text: doc.data().text,
    //       //     user: doc.data().user
    //       //   }))
    //       // );
    //     });
    // return unsubscribe;

    console.log("components mounted");
  }, []);

  function setprice(phoneName) {
    console.log(phoneName);
    if (phoneName == "another 13") {
      const message2 = {
        _id: Math.random().toString(36).substring(7),
        text: "i cant understand you",
        user: {
          _id: 2,
          name: "Chatbot",
          avatar: "https://placeimg.com/140/140/any",
        },
        createdAt: new Date(),
      };

      setMessages((previousMessages) =>
        GiftedChat.append(previousMessages, message2)
      );
    } else {
      console.log("else part called");
      const collectionRef = collection(database, "phone_prices");
      const q = query(collectionRef, where("phone_type", "==", phoneName));
      var price = "";

      const unsubscribe = onSnapshot(q, (querySnapshot) => {
        console.log("else part called");
        console.log("querySnapshot unsusbscribe");

        querySnapshot.docs.map((doc) => (price = doc.data().price));

        const message2 = {
          _id: Math.random().toString(36).substring(7),
          text: price,
          user: {
            _id: 2,
            name: "Chatbot",
            avatar: "https://placeimg.com/140/140/any",
          },
          createdAt: new Date(),
        };

        setMessages((previousMessages) =>
          GiftedChat.append(previousMessages, message2)
        );
      });
    }
  }

  function setLocations(phoneType) {
    console.log(phoneType);

    const collectionRef = collection(database, "phone_locations");
    const q = query(collectionRef, where("phone_type", "==", phoneType));
    const array1 = [];
    let newArray;

    const unsubscribe = onSnapshot(q, (querySnapshot) => {
      console.log("querySnapshot unsusbscribe");

      querySnapshot.docs.map(
        (doc) =>
          // console.log(doc.data().locations.length)
          (newArray = array1.concat(doc.data().locations))
      );
      console.log(newArray);
      console.log(newArray.length);
      const locationsString = newArray.join(", ");
      const message = `You can purchase this product in ${locationsString}.`;

      const message3 = {
        _id: Math.random().toString(36).substring(7),
        text: message,
        user: {
          _id: 2,
          name: "Chatbot",
          avatar: "https://placeimg.com/140/140/any",
        },
        createdAt: new Date(),
      };

      setMessages((previousMessages) =>
        GiftedChat.append(previousMessages, message3)
      );
    });
  }

  async function handleSend(newMessages = []) {
    const newMessage = newMessages[0];
    console.log("nemw message arrived");
    console.log(newMessage);

    setMessages((previousMessages) =>
      GiftedChat.append(previousMessages, newMessage)
    );

    const { _id, createdAt, text, user } = newMessage;
    // addDoc(collection(database, 'chats'), {
    // _id,
    // createdAt,
    // text,
    // user
    // });

    // addDoc(collection(database, 'phone_prices'), {
    //   _id:Math.random().toString(36).substring(7),
    //   createdAt:new Date(),
    //   phone_type:"iPhone 13",
    //   price:"200000 LKR"
    //   });

    if (newMessage.user._id === 1) {
      const URL = "http://0.0.0.0:3000";
      const data = {
        // Replace with the data you want to send to the backend
        _id: _id,
        text: encode(text),
      };
      fetch(`${URL}/data`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      })
        .then((response) => response.json())
        .then((data) => {
          console.log("Incoming", data.result);
          const decodedResult = decode(data.result);
          console.log("Decoded Result :", decodedResult);
          // greeting
          // product_info
          // goodbye

          if (decodedResult == "iPhone_13_price") {
            console.log("iPhone_13_price");
            setprice("iPhone 13");
          } else if (decodedResult == "iPhone_13_Pro_price") {
            console.log("iPhone_13_Pro_price");
            setprice("iPhone 13 Pro");
          } else if (decodedResult == "iPhone_13_Pro_Max_price") {
            console.log("iPhone_13_Pro_Max_price");
            setprice("iPhone 13 Pro Max");
          } else if (decodedResult == "iPhone_14_price") {
            console.log("iPhone_14_price");
            setprice("iPhone 14");
          } else if (decodedResult == "iPhone_14_Plus_price") {
            console.log("iPhone_14_Plus_price");
            setprice("iPhone 14 Plus");
          } else if (decodedResult == "iPhone_14_Pro_price") {
            console.log("iPhone_14_Pro_price");
            setprice("iPhone 14 Pro");
          } else if (decodedResult == "iPhone_13_locations") {
            console.log("iPhone_13_locations");
            setLocations("iPhone 13");
          } else if (decodedResult == "iPhone_13_pro_locations") {
            console.log("iPhone_13_pro_locations");
            setLocations("iPhone 13 Pro");
          } else if (decodedResult == "iPhone_13_pro_max_locations") {
            console.log("iPhone_13_pro_max_locations");
            setLocations("iPhone 13 Pro Max");
          } else if (decodedResult == "iPhone_14_locations") {
            console.log("iPhone_14_locations");
            setLocations("iPhone 14");
          } else if (decodedResult == "iPhone_14_plus_locations") {
            console.log("iPhone_14_plus_locations");
            setLocations("iPhone 14 Plus");
          } else if (decodedResult == "iPhone_14_pro_locations") {
            console.log("iPhone_14_pro_locations");
            setLocations("iPhone 14 Pro");
          } else {
            console.log("another");
            const message2 = {
              _id: Math.random().toString(36).substring(7),
              text: decodedResult,
              user: {
                _id: 2,
                name: "Chatbot",
                avatar: "https://placeimg.com/140/140/any",
              },
              createdAt: new Date(),
            };

            setMessages((previousMessages) =>
              GiftedChat.append(previousMessages, message2)
            );
          }
          //  console.log(data['result']);  // prints the parsed JavaScript object to the console
          //  const collectionRef = collection(database, 'phone_prices');
          //  const q = query(collectionRef,where('phone_type', '==', 'iPhone 13'));

          //  const unsubscribe = onSnapshot(q, querySnapshot => {
          //       console.log('querySnapshot unsusbscribe');
          //       querySnapshot.docs.map(doc =>
          //         price=doc.data().price,
          //         );
          //       const message2 = {
          //         _id: Math.random().toString(36).substring(7),
          //         text: price,
          //         user: {
          //                   _id: 2,
          //                   name: 'Chatbot',
          //                   avatar: 'https://placeimg.com/140/140/any',
          //               },
          //         createdAt: new Date(),
          //         // quickReplies:{
          //         //   type:'radio',
          //         //   keepIt:true,
          //         //   values:[
          //         //     {title:'mobilr phones',value:'mobile'},
          //         //     {title:'USA',value :'usa'},
          //         //   ]
          //         // }
          //       };

          //       setMessages(previousMessages =>
          //         GiftedChat.append(previousMessages, message2)
          //       );

          //});

          console.log("end of data feching");
        })
        .catch((error) => {
          // Handle any errors that occurred during the request
          console.error(error);
        });
    }
  }

  return (
    <GiftedChat
      messages={messages}
      onSend={handleSend}
      onQuickReply={onQuickReply}
      messagesContainerStyle={{
        backgroundColor: "#fff",
      }}
      textInputStyle={{
        backgroundColor: "#fff",
        borderRadius: 20,
      }}
      user={{
        _id: 1,
        name: "Me",
        avatar: "https://placeimg.com/140/140/any",
      }}
    />
  );

  // "proxy": "http://localhost:5000/",
}
