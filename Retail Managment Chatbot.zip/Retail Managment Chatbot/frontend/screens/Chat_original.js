import React, {
    useState,
    useEffect,
    useLayoutEffect,
    useCallback
  } from 'react';
  import { TouchableOpacity, Text } from 'react-native';
  import { GiftedChat } from 'react-native-gifted-chat';
  import {
    collection,
    addDoc,
    orderBy,
    query,
    onSnapshot
  } from 'firebase/firestore';
  import { signOut } from 'firebase/auth';
  import { auth, database } from '../config/firebase';
  import { useNavigation } from '@react-navigation/native';
  import { AntDesign } from '@expo/vector-icons';
  import colors from '../colors';


  export default function Chat() {

    const [messages, setMessages] = useState([]);
    const navigation = useNavigation();

  const onSignOut = () => {
      signOut(auth).catch(error => console.log('Error logging out: ', error));
    };

    useLayoutEffect(() => {
        navigation.setOptions({
          headerRight: () => (
            <TouchableOpacity
              style={{
                marginRight: 10
              }}
              onPress={onSignOut}
            >
              <AntDesign name="logout" size={24} color={colors.gray} style={{marginRight: 10}}/>
            </TouchableOpacity>
          )
        });
      }, [navigation]);

    useLayoutEffect(() => {

        const collectionRef = collection(database, 'chats');
        const q = query(collectionRef, orderBy('createdAt', 'desc'));

    const unsubscribe = onSnapshot(q, querySnapshot => {
        console.log('querySnapshot unsusbscribe');
          setMessages(
            querySnapshot.docs.map(doc => ({
              _id: doc.data()._id,
              createdAt: doc.data().createdAt.toDate(),
              text: doc.data().text,
              user: doc.data().user
            }))
          );
        });
    return unsubscribe;
      }, []);

    const onSend = useCallback((messages = []) => {
        setMessages(previousMessages =>
          GiftedChat.append(previousMessages, messages)
        );
        // setMessages([...messages, ...messages]);
        const { _id, createdAt, text, user } = messages[0];    
        addDoc(collection(database, 'chats'), {
          _id,
          createdAt,
          text,
          user
        });
      }, []);

      return (
        // <>
        //   {messages.map(message => (
        //     <Text key={message._id}>{message.text}</Text>
        //   ))}
        // </>
        <GiftedChat
          messages={messages}
          showAvatarForEveryMessage={false}
          showUserAvatar={false}
          onSend={messages => onSend(messages)}
          messagesContainerStyle={{
            backgroundColor: '#fff'
          }}
          textInputStyle={{
            backgroundColor: '#fff',
            borderRadius: 20,
          }}
          user={{
            _id: auth?.currentUser?.email,
            avatar: 'https://i.pravatar.cc/300'
          }}
        />
      );
}


////////////////////working code /////////////////////////

// import React, {
//   useState,
//   useEffect,
//   useLayoutEffect,
//   useCallback
// } from 'react';
// import { TouchableOpacity, Text } from 'react-native';
// import { GiftedChat } from 'react-native-gifted-chat';
// import {
//   collection,
//   addDoc,
//   orderBy,
//   query,
//   onSnapshot
// } from 'firebase/firestore';
// import { signOut } from 'firebase/auth';
// import { auth, database } from '../config/firebase';
// import { useNavigation } from '@react-navigation/native';
// import { AntDesign } from '@expo/vector-icons';
// import colors from '../colors';


// export default function Chat() {

//   const [messages, setMessages] = useState([]);
//   const navigation = useNavigation();


//   const onSignOut = () => {
//       signOut(auth).catch(error => console.log('Error logging out: ', error));
//     };

//     useLayoutEffect(() => {
//         navigation.setOptions({
//           headerRight: () => (
//             <TouchableOpacity
//               style={{
//                 marginRight: 10
//               }}
//               onPress={onSignOut}
//             >
//               <AntDesign name="logout" size={24} color={colors.gray} style={{marginRight: 10}}/>
//             </TouchableOpacity>
//           )
//         });
//       }, [navigation]);

//   useEffect(() => {
//       const collectionRef = collection(database, 'chats');
//       const q = query(collectionRef, orderBy('createdAt', 'desc'));

//       const unsubscribe = onSnapshot(q, querySnapshot => {
//           console.log('querySnapshot unsusbscribe');
//             setMessages(
//               querySnapshot.docs.map(doc => ({
//                 _id: doc.data()._id,
//                 createdAt: doc.data().createdAt.toDate(),
//                 text: doc.data().text,
//                 user: doc.data().user
//               }))
//             );
//           });
//       return unsubscribe;
//     }, []);

    
//   async function handleSend(newMessages=[]) {
//       const newMessage = newMessages[0];
//       console.log(newMessage);

//       setMessages(previousMessages =>
//           GiftedChat.append(previousMessages, newMessage)
//       );
//       const { _id, createdAt, text, user } = newMessage;    
//       console.log(_id);
//       addDoc(collection(database, 'chats'), {
//       _id,
//       createdAt,
//       text,
//       user
//       });
      
  
//       if (newMessage.user._id === 1) {
//           const autoReply = 'Thank you for your message! Our team will get back to you as soon as possible.';
    
//           addDoc(collection(database, 'chats'),{
//               _id: Math.random().toString(36).substring(7),
//               text: autoReply,
//               createdAt: new Date(),
//               user: {
//                   _id: 2,
//                   name: 'Chatbot',
//                   avatar: 'https://placeimg.com/140/140/any',
//               },
//               });
//           console.log(autoReply);
//         }
//   };

//   return (
      
//         <GiftedChat
//           messages={messages}
//           onSend={handleSend}
//           messagesContainerStyle={{
//               backgroundColor: '#fff'
//             }}
//             textInputStyle={{
//               backgroundColor: '#fff',
//               borderRadius: 20,
//             }}
//           user={{
//             _id: 1,
//             name: 'Me',
//             avatar: 'https://placeimg.com/140/140/any',
//           }}
//         />
      
//     );




 
  
// }



