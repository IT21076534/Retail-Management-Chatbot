from flask import Flask, jsonify, request
from flask_cors import CORS

#importing the libraries
import tensorflow as tf
import numpy 
import pandas as pd
import json
import nltk
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.layers import Input, Embedding, LSTM , Dense, GlobalMaxPooling1D, Flatten
from tensorflow.keras.models import Model
import matplotlib.pyplot as plt
import string
from pandas.core.computation.parsing import tokenize
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence  import pad_sequences
from keras.models import load_model
import random
#demonstrate prediction for next 10 days
from numpy import array
import pickle
import base64

from sklearn.preprocessing import LabelEncoder
# tokenizer=Tokenizer(num_words=2000)

model1 = load_model("models//LSTM_ChatBot_Retailer.h5")

#import dataset
with  open('models//content.json') as content:
  data1=json.load(content)

#import dataset
with  open('models//contentRetailer.json') as content1:
  data2=json.load(content1)


#getting all the data to list
tags=[]
inputs=[]
responses={}
for intent in data1['intents']:
  responses[intent['tag']]=intent['responses']
  for line in intent['input']:
    inputs.append(line)
    tags.append(intent['tag'])


tags_re=[]
inputs_re=[]
responses_re={}
for intent1 in data2['intents']:
  responses_re[intent1['tag']]=intent1['responses']
  for line1 in intent1['input']:
    inputs_re.append(line1)
    tags_re.append(intent1['tag'])



app = Flask(__name__)
CORS(app)


@app.route('/data', methods=['POST'])
def endpoint():
        model = load_model("models//LSTM_ChatBot_Customer.h5")
        # Load the tokenizer from disk
        with open('models//tokenizer.pickle', 'rb') as handle:
            tokenizer = pickle.load(handle)

        # Load the label encoder from disk
        with open('models//label_encoder.pickle', 'rb') as handle:
            le = pickle.load(handle)

        input_shape=18
        # Get the data from the request body
        data = request.get_json()
        print(data)
        print("called")
        print("Incomming Data :",data["text"])
        decoded_text = base64.b64decode(data['text']).decode('utf-8')
        print("Decoded Text :",decoded_text)

        # Process the data
        prediction_input = decoded_text
        texts_p = []
        
        #removing punctuation and converting to lowercase
        prediction_input = [letters.lower() for letters in prediction_input if letters not in string.punctuation] 
        prediction_input=''.join(prediction_input)
        texts_p.append(prediction_input)

        #tokenizing and padding
        
        prediction_input = tokenizer.texts_to_sequences (texts_p)
        prediction_input = numpy.array(prediction_input).reshape(-1)
        prediction_input = pad_sequences ([prediction_input], input_shape)

        #getting output from model
        output= model.predict(prediction_input)
        output = output.argmax()

        response_tags=["iPhone_13_locations","iPhone_13_pro_locations",
                    "iPhone_13_pro_max_locations","iPhone_14_locations","iPhone_14_plus_locations",
                    "iPhone_14_pro_locations","iPhone_13_price","iPhone_13_Pro_price",
                    "iPhone_13_Pro_Max_price","iPhone_14_price","iPhone_14_Plus_price","iPhone_14_Pro_price"]

        response_tag= le.inverse_transform([output])[0]

        if response_tag not in response_tags:
            bot_responce=random.choice(responses [response_tag])
            print("bot_responce :",bot_responce)
            try:
                encoded_response = base64.b64encode(bot_responce.encode('utf-8')).decode('utf-8')
            except:

                encoded_response = "Error encoding response"
            
            print("encoded_response",encoded_response)
            return jsonify({'result': encoded_response})
        else:
            print("response_tag :",response_tag)
            return jsonify({'result':response_tag})


    

def forecastSales():
    model = load_model("models//LSTM_.h5")
    # Load the scaler from disk
    with open('models//scaler.pickle', 'rb') as handle:
        scaler = pickle.load(handle)

    temp_input=[0.6461285684945575,0.652084616964469,0.6771410967344424,0.6461285684945575,0.6237420414869583,
                0.623331279523516,0.623331279523516,0.6869993838570547,0.973505853357979,0.5060587389607722,0.5064695009242144,               
                0.6424317108235778,0.5783528445265969,0.6974738139248307,0.7060998151571165,0.7110289587184226, 
                0.6976791949065517,0.6360649003902239, 0.6646128568494556,0.7453275826658452, 1.0]  
    x_input=[[0.6461285684945575,0.652084616964469,0.6771410967344424,0.6461285684945575,0.6237420414869583,
                0.623331279523516,0.623331279523516,0.6869993838570547,0.973505853357979,0.5060587389607722,0.5064695009242144,               
                0.6424317108235778,0.5783528445265969,0.6974738139248307,0.7060998151571165,0.7110289587184226, 
                0.6976791949065517,0.6360649003902239, 0.6646128568494556,0.7453275826658452, 1.0]]
                          
                
    lst_output=[]
    i=0
    n_steps=20
    while(i<5):
        if(len(temp_input)>20):
            x_input=numpy.array(temp_input[1:])
            x_input=x_input.reshape(1,-1)
            x_input= x_input.reshape((1, 20, 1))
            yhat = model.predict(x_input, verbose=0)
            temp_input.extend(yhat[0].tolist())
            temp_input=temp_input[1:]
            lst_output.extend(yhat.tolist())
            i=i+1
        else:
            x_input = x_input.reshape((1, n_steps,1))
            yhat = model.predict(x_input, verbose=0)
            temp_input.extend(yhat[0].tolist())
            lst_output.extend(yhat.tolist())
            i=i+1

    print(type(lst_output))
    lst_output1=scaler.inverse_transform(lst_output).tolist()
    print(type(lst_output1))

    one_d_list = []

    one_d_list = [element for sublist in lst_output1 for element in sublist]

    return one_d_list


def forecastStock():
    model = load_model("models//LSTM_Sock_.h5")
    # Load the scaler from disk
    with open('models//scaler_stock.pickle', 'rb') as handle:
        scaler = pickle.load(handle)

    temp_input=[0.3102364577093846,
                0.19854137848316003,
                0.17475699217577292,
                0.23389601836330443,
                0.21674990770945646,
                0.1943434156263332,
                0.21089861542638233,
                0.21087491435293915,
                0.2732678106384782,
                0.2805758211703734,
                0.8507069383815183,
                0.5399662942007064,
                0.3675413440088714,
                0.366326843548496,
                0.321904747540475,
                0.30754512899847886,
                0.456482135854553,
                0.44702666442583794,
                0.42990910279227373,
                0.399675331204546,
                0.3507613431182856,
                0.3611528273944189,
                0.5422196917136738,
                0.3105824574709375,
                0.3721055961825471,
                0.3983739268082124,
                0.36538652141499717,
                0.37925901107630167,
                0.44581198441187586,
                0.3763637094909153] 
    
    x_input=[[0.3102364577093846,
                0.19854137848316003,
                0.17475699217577292,
                0.23389601836330443,
                0.21674990770945646,
                0.1943434156263332,
                0.21089861542638233,
                0.21087491435293915,
                0.2732678106384782,
                0.2805758211703734,
                0.8507069383815183,
                0.5399662942007064,
                0.3675413440088714,
                0.366326843548496,
                0.321904747540475,
                0.30754512899847886,
                0.456482135854553,
                0.44702666442583794,
                0.42990910279227373,
                0.399675331204546,
                0.3507613431182856,
                0.3611528273944189,
                0.5422196917136738,
                0.3105824574709375,
                0.3721055961825471,
                0.3983739268082124,
                0.36538652141499717,
                0.37925901107630167,
                0.44581198441187586,
                0.3763637094909153]]
                          
                
    from numpy import array

    lst_output=[]
    n_steps=30
    i=0
    while(i<5):
        
        if(len(temp_input)>30):
            x_input=numpy.array(temp_input[1:])
            x_input=x_input.reshape(1,-1)
            x_input = x_input.reshape((1,n_steps,1))
            yhat = model.predict(x_input, verbose=0)
            temp_input.extend(yhat[0].tolist())
            temp_input=temp_input[1:]
            lst_output.extend(yhat.tolist())
            i=i+1
        else:
            x_input = numpy.array(x_input).reshape((1,n_steps,1))
            yhat = model.predict(x_input, verbose=0)
            print(yhat[0])
            temp_input.extend(yhat[0].tolist())
            print(len(temp_input))
            lst_output.extend(yhat.tolist())
            i=i+1

    print(type(lst_output))
    lst_output1=scaler.inverse_transform(lst_output).tolist()
    print(type(lst_output1))

    one_d_list = []

    one_d_list = [element for sublist in lst_output1 for element in sublist]

    return one_d_list
    


@app.route('/admin', methods=['POST'])
def endpointAdmin():

    model1 = load_model("models//LSTM_ChatBot_Retailer.h5")

    with open('models//tokenizer_retailer.pickle', 'rb') as handle1:
        tokenizer_re = pickle.load(handle1)

    # Load the label encoder from disk
    with open('models//label_encoder_retailer.pickle', 'rb') as handle1:
        le_re = pickle.load(handle1)

    input_shape_re=17

    # # Get the data from the request body
    data1 = request.get_json()
    # print(data)
    # print("called")

    # # Process the data
    prediction_input = data1['text']
    texts_p = []
    
    # # #removing punctuation and converting to lowercase
    prediction_input = [letters.lower() for letters in prediction_input if letters not in string.punctuation] 
    prediction_input=''.join(prediction_input)
    texts_p.append(prediction_input)

    # # #tokenizing and padding
    
    prediction_input = tokenizer_re.texts_to_sequences (texts_p)
    prediction_input = numpy.array(prediction_input).reshape(-1)
    prediction_input = pad_sequences ([prediction_input], input_shape_re)

    # # #getting output from model
    output= model1.predict(prediction_input)
    output = output.argmax()

    response_tags=["sales_month","sales_year",
                   "sales_total","stock_month","stock_year",
                   "sales_forecast","stock_forecast"
                  ]
    
    response_tag= le_re.inverse_transform([output])[0]

    if response_tag=="sales_forecast":
       forecast_sale_values=forecastSales()
       rounded_nums = [round(num*100, 2) for num in forecast_sale_values]
       message=f"This is Sales Forecasting Value for the Next 5 Months\n\nFirst :{rounded_nums[0]} LKR\nSecond:{rounded_nums[1]} LKR \nThird: {rounded_nums[2]} LKR\nForth: {rounded_nums[3]} LKR\nFifth:{rounded_nums[4]} LKR "
       return jsonify({'result':message})
    
    elif response_tag=="stock_forecast":
       forecast_stock_values=forecastStock()
       rounded_nums = [round(num/1000000, 2) for num in forecast_stock_values]
       message=f"This is Stock Forecasting Value for the Next 5 Months\n\nFirst :{rounded_nums[0]} Pcs\nSecond:{rounded_nums[1]} Pcs \nThird: {rounded_nums[2]} Psc\nForth: {rounded_nums[3]} Psc\nFifth:{rounded_nums[4]} Psc "
       return jsonify({'result':message})
    
    elif response_tag not in response_tags:
        bot_responce=random.choice(responses_re [response_tag])
        return jsonify({'result':bot_responce})
    else:
        return jsonify({'result':response_tag})

    

@app.route("/")
def hello_world():
    return "<p>Hello, World!</p>"

if __name__ == '__main__':
    app.run(host='0.0.0.0',port='3000',debug=True)
    #flask run -h 192.168.8.196 -p 3000